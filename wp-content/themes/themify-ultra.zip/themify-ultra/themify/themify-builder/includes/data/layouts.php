<?php

return array(
	array(
		'title' => 'Agency',
		'data'  => 'agency.zip',
		'thumb' => '%s/thumb-agency.jpg'
	),
	array(
		'title' => 'Agency 2',
		'data'  => 'agency-2.zip',
		'thumb' => '%s/thumb-agency-2.jpg'
	),
	array(
		'title' => 'App',
		'data'  => 'app.zip',
		'thumb' => '%s/thumb-app.jpg'
	),
	array(
		'title' => 'App 2',
		'data'  => 'app-2.zip',
		'thumb' => '%s/thumb-app-2.jpg'
	),
	array(
		'title' => 'App 3',
		'data'  => 'app-3.zip',
		'thumb' => '%s/thumb-app-3.jpg'
	),
	array(
		'title' => 'App 4',
		'data'  => 'app-4.zip',
		'thumb' => '%s/thumb-app-4.jpg'
	),	
	array(
		'title' => 'App 5',
		'data'  => 'app-5.zip',
		'thumb' => '%s/thumb-app-5.jpg'
	),	
	array(
		'title' => 'App 6',
		'data'  => 'app-6.zip',
		'thumb' => '%s/thumb-app-6.jpg'
	),	
	array(
		'title' => 'App 7',
		'data'  => 'app-7.zip',
		'thumb' => '%s/thumb-app-7.jpg'
	),	
	array(
		'title' => 'App 8',
		'data'  => 'app-8.zip',
		'thumb' => '%s/thumb-app-8.jpg'
	),		
    array(
		'title' => 'Blog',
		'data'  => 'blog.zip',
		'thumb' => '%s/thumb-blog.jpg'
	),
	array(
		'title' => 'Coming Soon',
		'data'  => 'coming-soon.zip',
		'thumb' => '%s/thumb-coming-soon.jpg'
	),
	array(
		'title' => 'Company',
		'data'  => 'company.zip',
		'thumb' => '%s/thumb-company.jpg'
	),
	array(
		'title' => 'Company 2',
		'data'  => 'company-2.zip',
		'thumb' => '%s/thumb-company-2.jpg'
	),
	array(
		'title' => 'Company 3',
		'data'  => 'company-3.zip',
		'thumb' => '%s/thumb-company-3.jpg'
	),	
	array(
		'title' => 'Corporate',
		'data'  => 'corporate.zip',
		'thumb' => '%s/thumb-corporate.jpg'
	),
	array(
		'title' => 'Corporate 2',
		'data'  => 'corporate-2.zip',
		'thumb' => '%s/thumb-corporate-2.jpg'
	),	
	array(
		'title' => 'Ebook',
		'data'  => 'ebook.zip',
		'thumb' => '%s/thumb-ebook.jpg'
	),
	array(
		'title' => 'Ebook 2',
		'data'  => 'ebook-2.zip',
		'thumb' => '%s/thumb-ebook-2.jpg'
	),
	array(
		'title' => 'Event',
		'data'  => 'event.zip',
		'thumb' => '%s/thumb-event.jpg'
	),
	array(
		'title' => 'Event 2',
		'data'  => 'event-2.zip',
		'thumb' => '%s/thumb-event-2.jpg'
	),
	array(
		'title' => 'Fullscreen',
		'data'  => 'fullscreen.zip',
		'thumb' => '%s/thumb-fullscreen.jpg'
	),
	array(
		'title' => 'Fullscreen 2',
		'data'  => 'fullscreen-2.zip',
		'thumb' => '%s/thumb-fullscreen-2.jpg'
	),
	array(
		'title' => 'Marketer',
		'data'  => 'marketer.zip',
		'thumb' => '%s/thumb-marketer.jpg'
	),
	array(
		'title' => 'Marketer 2',
		'data'  => 'marketer-2.zip',
		'thumb' => '%s/thumb-marketer-2.jpg'
	),
	array(
		'title' => 'Masonry Image',
		'data'  => 'masonry.zip',
		'thumb' => '%s/thumb-masonry-image.jpg'
	),
	array(
		'title' => 'Music',
		'data'  => 'music.zip',
		'thumb' => '%s/thumb-music.jpg'
	),
	array(
		'title' => 'Music 2',
		'data'  => 'music-2.zip',
		'thumb' => '%s/thumb-music-2.jpg'
	),
	array(
		'title' => 'Music 3',
		'data'  => 'music-3.zip',
		'thumb' => '%s/thumb-music-3.jpg'
	),	
	array(
		'title' => 'Personal',
		'data'  => 'personal.zip',
		'thumb' => '%s/thumb-personal.jpg'
	),
	array(
		'title' => 'Portfolio',
		'data'  => 'portfolio.zip',
		'thumb' => '%s/thumb-portfolio.jpg'
	),
	array(
		'title' => 'Portfolio 2',
		'data'  => 'portfolio-2.zip',
		'thumb' => '%s/thumb-portfolio-2.jpg'
	),
	array(
		'title' => 'Portfolio 3',
		'data'  => 'portfolio-3.zip',
		'thumb' => '%s/thumb-portfolio-3.jpg'
	),
	array(
		'title' => 'Portfolio 4',
		'data'  => 'portfolio-4.zip',
		'thumb' => '%s/thumb-portfolio-4.jpg'
	),	
	array(
		'title' => 'Post Slider',
		'data'  => 'post-slider.zip',
		'thumb' => '%s/thumb-post-slider.jpg'
	),
	array(
		'title' => 'Product',
		'data'  => 'product.zip',
		'thumb' => '%s/thumb-product.jpg'
	),
	array(
		'title' => 'Product 2',
		'data'  => 'product-2.zip',
		'thumb' => '%s/thumb-product-2.jpg'
	),
	array(
		'title' => 'Product 3',
		'data'  => 'product-3.zip',
		'thumb' => '%s/thumb-product-3.jpg'
	),
	array(
		'title' => 'Product 4',
		'data'  => 'product-4.zip',
		'thumb' => '%s/thumb-product-4.jpg'
	),
	array(
		'title' => 'Product 5',
		'data'  => 'product-5.zip',
		'thumb' => '%s/thumb-product-5.jpg'
	),	
	array(
		'title' => 'Product 6',
		'data'  => 'product-6.zip',
		'thumb' => '%s/thumb-product-6.jpg'
	),	
	array(
		'title' => 'Product 7',
		'data'  => 'product-7.zip',
		'thumb' => '%s/thumb-product-7.jpg'
	),	
	array(
		'title' => 'Product 8',
		'data'  => 'product-8.zip',
		'thumb' => '%s/thumb-product-8.jpg'
	),	
	array(
		'title' => 'Restaurant',
		'data'  => 'restaurant.zip',
		'thumb' => '%s/thumb-restaurant.jpg'
	),
	array(
		'title' => 'Restaurant 2',
		'data'  => 'restaurant-2.zip',
		'thumb' => '%s/thumb-restaurant-2.jpg'
	),
	array(
		'title' => 'Resume',
		'data'  => 'resume.zip',
		'thumb' => '%s/thumb-resume.jpg'
	),	
	array(
		'title' => 'Shop',
		'data'  => 'shop.zip',
		'thumb' => '%s/thumb-shop.jpg'
	),
	array(
		'title' => 'Shop 2',
		'data'  => 'shop-2.zip',
		'thumb' => '%s/thumb-shop-2.jpg'
	),	
	array(
		'title' => 'Wedding',
		'data'  => 'wedding.zip',
		'thumb' => '%s/thumb-wedding.jpg'
	),
	array(
		'title' => 'App',
		'data'  => 'app-parallax.zip',
		'thumb' => '%s/thumb-app-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'boutique',
		'data'  => 'boutique-parallax.zip',
		'thumb' => '%s/thumb-boutique-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Features',
		'data'  => 'features-parallax.zip',
		'thumb' => '%s/thumb-features-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Gradient',
		'data'  => 'gradient-parallax.zip',
		'thumb' => '%s/thumb-gradient-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Gym',
		'data'  => 'gym-parallax.zip',
		'thumb' => '%s/thumb-gym-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Hiking',
		'data'  => 'hiking-parallax.zip',
		'thumb' => '%s/thumb-hiking-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Profile',
		'data'  => 'profile-parallax.zip',
		'thumb' => '%s/thumb-profile-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Restaurant',
		'data'  => 'restaurant-parallax.zip',
		'thumb' => '%s/thumb-restaurant-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Spa',
		'data'  => 'spa-parallax.zip',
		'thumb' => '%s/thumb-spa-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Timeline',
		'data'  => 'timeline-parallax.zip',
		'thumb' => '%s/thumb-timeline-parallax.jpg',
		'group' => 'parallax',
	),
	array(
		'title' => 'Wine',
		'data'  => 'wine-parallax.zip',
		'thumb' => '%s/thumb-wine-parallax.jpg',
		'group' => 'parallax',
	),
);